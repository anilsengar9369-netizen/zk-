# ZkSharma Telegram Bot

## Setup (Without Docker)

1️⃣ Install dependencies  
pip install -r requirements.txt

2️⃣ Rename `.env.example` to `.env`  
Add:
TOKEN=
OWNER_USERNAME=
OWNER_ID=

3️⃣ Run bot  
python zksharma_bot.py


## Setup (With Docker)

1️⃣ Build  
docker build -t zksharma-bot .

2️⃣ Run  
docker run --env-file .env zksharma-bot
