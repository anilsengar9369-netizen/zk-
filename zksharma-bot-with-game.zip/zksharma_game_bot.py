import os
import random
from collections import defaultdict
from dotenv import load_dotenv
from telegram import Update, ChatPermissions
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# Load .env
load_dotenv()

# ⚠️ BOT TOKEN (From .env)
TOKEN = os.getenv("TOKEN")
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "@Zksharma")
OWNER_ID = int(os.getenv("OWNER_ID", "123456789"))

# ===== GAME DATA =====
kills = defaultdict(int)
robs = defaultdict(int)

# ===== START =====
def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "𝐈, 𝐁𝐚𝐤𝐚 𝐓ʜᴇ Sᴏᴜʟ Oғ Dᴇᴠᴇʟᴏᴘᴇʀ ~ 𝐙𝐤 𝐒𝐡𝐚𝐫𝐦𝐚\n"
        f"Uᴘᴅᴀᴛᴇs : {OWNER_USERNAME}\n\n"
        "🎮 /kill @user\n"
        "🎮 /rob @user\n"
        "🏆 /leaderboard"
    )

# ===== KILL =====
def kill(update: Update, context: CallbackContext):
    if not context.args:
        update.message.reply_text("Example: /kill @username")
        return
    killer = update.effective_user.first_name
    kills[killer] += 1
    update.message.reply_text(random.choice([
        f"🔪 {killer} ne game me kill kar diya 😎",
        f"💣 {killer} OP nikla 😂",
        f"🔥 Fatal move by {killer}"
    ]))

# ===== ROB =====
def rob(update: Update, context: CallbackContext):
    if not context.args:
        update.message.reply_text("Example: /rob @username")
        return
    robber = update.effective_user.first_name
    robs[robber] += 1
    update.message.reply_text(random.choice([
        f"💰 {robber} ne loot liya 😂",
        f"🕵️ Clean rob by {robber}",
        f"🚓 Police se bach gaya 😆"
    ]))

# ===== LEADERBOARD =====
def leaderboard(update: Update, context: CallbackContext):
    if not kills:
        update.message.reply_text("Abhi koi data nahi hai 😅")
        return
    text = "🏆 LEADERBOARD 🏆\n\n"
    for u in kills:
        text += f"{u} → 🔪 {kills[u]} | 💰 {robs[u]}\n"
    update.message.reply_text(text)

# ===== ADMIN CHECK =====
def is_admin(update, uid):
    member = update.effective_chat.get_member(uid)
    return member.status in ["administrator", "creator"]

# ===== MUTE =====
def mute(update: Update, context: CallbackContext):
    if not update.message.reply_to_message:
        return
    uid = update.effective_user.id
    if uid != OWNER_ID and not is_admin(update, uid):
        update.message.reply_text("❌ Sirf admin / owner")
        return
    target = update.message.reply_to_message.from_user.id
    update.effective_chat.restrict_member(
        target, ChatPermissions(can_send_messages=False)
    )
    update.message.reply_text("🔇 User muted")

# ===== BAN =====
def ban(update: Update, context: CallbackContext):
    if not update.message.reply_to_message:
        return
    uid = update.effective_user.id
    if uid != OWNER_ID and not is_admin(update, uid):
        update.message.reply_text("❌ Sirf admin / owner")
        return
    target = update.message.reply_to_message.from_user.id
    update.effective_chat.ban_member(target)
    update.message.reply_text("⛔ User banned")

# ===== 100+ HUMAN REPLIES =====
HUMAN_REPLIES = [
    "haan bolo 😄", "samajh gaya 👍", "acha hai 😎", "kya scene hai?",
    "😂😂", "arey wah!", "theek hai bhai", "hmm 🤔", "bolo na",
    "haan haan", "kya help chahiye?", "mast 🔥", "lol",
    "are bhai 😂", "nice", "cool bro", "samajh raha hu",
    "thoda ruk", "abhi bolta hu", "haan suna",
] * 6  # 120+ replies

# ===== CHAT HANDLER =====
def human_chat(update: Update, context: CallbackContext):
    msg = update.message.text.lower()

    if "owner" in msg or "malik" in msg or "creator" in msg:
        update.message.reply_text(f"👑 Mere owner hai {OWNER_USERNAME}")
        return

    if "@zksharmabot" in msg:
        update.message.reply_text(random.choice(HUMAN_REPLIES))

# ===== MAIN =====
def main():
    if not TOKEN:
        print("❌ BOT TOKEN NOT FOUND IN .env")
        return

    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("kill", kill))
    dp.add_handler(CommandHandler("rob", rob))
    dp.add_handler(CommandHandler("leaderboard", leaderboard))
    dp.add_handler(CommandHandler("mute", mute))
    dp.add_handler(CommandHandler("ban", ban))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, human_chat))

    print("🚀 Game Bot Started!")
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
