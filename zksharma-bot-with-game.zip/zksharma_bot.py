import os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext

load_dotenv()

TOKEN = os.getenv("TOKEN")
OWNER_USERNAME = os.getenv("OWNER_USERNAME")
OWNER_ID = os.getenv("OWNER_ID")

def start(update: Update, context: CallbackContext):
    update.message.reply_text("🤖 Bot is running successfully!")

def owner(update: Update, context: CallbackContext):
    update.message.reply_text(f"Bot Owner: {OWNER_USERNAME} ({OWNER_ID})")

def main():
    if not TOKEN:
        print("❌ BOT TOKEN NOT FOUND IN .env")
        return

    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("owner", owner))

    print("🚀 Bot Started Successfully!")
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
